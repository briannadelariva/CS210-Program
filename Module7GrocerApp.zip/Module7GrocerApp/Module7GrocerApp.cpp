// Module7GrocerApp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <map>
#include <string>

using namespace std;

class GrocerProgram {
private:
    map<string, int> wordFrequency;  // Store word-frequency pairs

    // Private member functions for internal operations
    void loadDataFromFile(const string& filename) {
        ifstream inputFile(filename);
        if (inputFile.is_open()) {
            string word;
            int frequency;
            while (inputFile >> word) {
                frequency = wordFrequency[word];
                // if frequency == null {frequency = 0}
                frequency++;
                wordFrequency[word] = frequency;

            }
            inputFile.close();
            //cout << "WordFrequency" << wordFrequency.size() << endl;
        }
    }

    void saveDataToBackupFile(const string& filename) {
        ofstream outputFile(filename);
        if (outputFile.is_open()) {
            for (const auto& pair : wordFrequency) {
                outputFile << pair.first << " " << pair.second << endl;
            }
            outputFile.close();
        }
    }

public:
    // Constructor
    GrocerProgram() {
        // Load data from the input file and populate the wordFrequency map
//        loadDataFromFile("U:\Module7GrocerApp\Module7GrocerApp\Module7GrocerApp\words.txt");
        loadDataFromFile("words.txt");
    }

    // Destructor
    ~GrocerProgram() {
        // Save data to the backup file when the program exits
        saveDataToBackupFile("frequency.dat");
    }

    // Public member functions for menu options
    void findFrequencyOfWord(const string& word) {
        cout << wordFrequency[word] << endl;

    }

    void printFrequencyList() {
        // Implement Option Two - Print Frequency List
        // ...
        for (const auto& pair : wordFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }
    // Prints the histogram utilizing the * sign.
    void printHistogram() {

        int maxWidth = 60;
        int wordWidth = 12;

        int maxFrequency = 0;
        int maxWordWidth = 0;
        for (const auto& pair : wordFrequency) {
            if (pair.second > maxFrequency) {
                maxFrequency = pair.second;
            }
            if (pair.first.length() > maxWordWidth) {
                maxWordWidth = pair.first.length();
            }
        }

        for (const auto& pair : wordFrequency) {
            int frequency = pair.second;
            float percent = static_cast<float>(frequency) / maxFrequency;
            int stars = static_cast<int>(percent * maxWidth);
            std::string startString;
            // Print stars based on the calculated count
            for (int i = 0; i < stars; i++) {
                startString += "*";
            }
            std::string spacePad;
            int padWidth = wordWidth - pair.first.length();
            for (int i = 0; i < padWidth; i++) {
                spacePad += " ";
            }


            cout << pair.first << spacePad << startString << endl;


        }
    }
};

int main() {
    GrocerProgram program;

    int choice;
    while (true) {
        cout << "Menu Options:\n";
        cout << "1. Find Frequency of a Word\n";
        cout << "2. Print Frequency List\n";
        cout << "3. Print Histogram\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
        {
            string word;
            cout << "Enter the word to search for: ";
            cin >> word;
            program.findFrequencyOfWord(word);
        }
        break;
        case 2:
            program.printFrequencyList();
            break;
        case 3:
            program.printHistogram();
            break;
        case 4:
            return 0;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}
